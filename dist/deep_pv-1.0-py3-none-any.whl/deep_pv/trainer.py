def train_model():
    pass
if __name__ == '__main__':
    """ runs a training """
    train_model()
